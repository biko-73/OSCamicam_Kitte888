#!/bin/sh

LOG_FILE="/tmp/camstart.log"
CAMNAME="oscamicam"

remove_tmp() {
	rm -rf /tmp/*.info* /tmp/*.tmp* /tmp/*share* /tmp/*.pid* /tmp/*sbox* /tmp/oscam* /tmp/.oscam
}

case "$1" in
start)
	echo "cam start " >> $LOG_FILE
	echo "[SCRIPT] $1: $CAMNAME"
	remove_tmp
	#/usr/bin/${CAMNAME} -b -r2  --config-dir /etc/tuxbox/config/oscamicam &

	CAM_UP_OUTPUT="$(/usr/bin/$CAMNAME -b -r2  --config-dir /etc/tuxbox/config/oscamicam 2>&1)"
    
					if [ $? -ne 0 ]; then
						ERROR_MESSAGE="Fehler beim Starten der Kamera: $CAM_UP_OUTPUT"
						echo "$ERROR_MESSAGE" >> $LOG_FILE
						#wget -qO- "http://localhost/web/message?text=$ERROR_MESSAGE&type=2&timeout=5" &>/dev/null
						#sleep 5  # Warte eine kurze Zeit, damit die Ausgabe in die Datei geschrieben wird
					fi
	echo "cam start ende" >> $LOG_FILE
	;;
# /usr/bin/oscamicam -b -r2  --config-dir /etc/tuxbox/config/oscamicam


stop)
	echo "cam stop befehl " >> $LOG_FILE
	echo "[SCRIPT] $1: $CAMNAME"
	killall -9 ${CAMNAME} 2>/dev/null
	sleep 1
	remove_tmp
	;;
*)
	$0 stop
	exit 0
	;;
esac

exit 0
