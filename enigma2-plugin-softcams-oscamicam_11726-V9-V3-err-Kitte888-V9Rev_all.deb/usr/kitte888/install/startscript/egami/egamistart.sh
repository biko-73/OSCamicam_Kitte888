#!/bin/sh

LOG_FILE="/tmp/camstart.log"
CAMNAME="oscamicam"

remove_tmp() {
	rm -rf /tmp/*.info* /tmp/*.tmp* /tmp/*share* /tmp/*.pid* /tmp/*sbox* /tmp/oscam* /tmp/.oscam
}

case "$1" in
start)
	echo "cam start " >> $LOG_FILE
	echo "[SCRIPT] $1: $CAMNAME"
	remove_tmp
	#/usr/bin/${CAMNAME} -b -r2  --config-dir /etc/tuxbox/config/oscamicam &

	CAM_UP_OUTPUT="$(/usr/bin/$CAMNAME -b -r2  --config-dir /etc/tuxbox/config/oscamicam 2>&1)"
    
					if [ $? -gt 0 ]; then
						ERROR_MESSAGE="Fehler beim Starten der Oscam: $CAM_UP_OUTPUT"
						echo "$ERROR_MESSAGE" >> $LOG_FILE
						$WGET -O -q "http://localhost/web/message?text=${MESSAGE// /%20}&type=0&timeout=5" /dev/null
						sleep 3
						$WGET -O -q "http://localhost/web/message?text=Cam+not+Startet+Error!!!+---+logfile+---+tmp/OscamStartError.log&type=1&timeout=10" /dev/null
						sleep 10
					fi
	echo "cam start ende" >> $LOG_FILE
	;;
# /usr/bin/oscamicam -b -r2  --config-dir /etc/tuxbox/config/oscamicam


stop)
	echo "cam stop befehl " >> $LOG_FILE
	echo "[SCRIPT] $1: $CAMNAME"
	killall -9 ${CAMNAME} 2>/dev/null
	sleep 1
	remove_tmp
	;;
*)
	$0 stop
	exit 0
	;;
esac

exit 0
