#!/bin/sh

LOG_FILE="/tmp/camstart.log"
CAMNAME="oscamicam"

remove_tmp() {
  rm -rf /tmp/*.info* /tmp/*.tmp* /tmp/*share* /tmp/*.pid* /tmp/*sbox* /tmp/oscam* /tmp/.oscam
}

case "$1" in
start)
  echo "cam start " >> $LOG_FILE
  echo "[SCRIPT] $1: $CAMNAME"
  remove_tmp
  touch /tmp/.emu.info
  echo ${CAMNAME} >/tmp/.emu.info
  #/usr/bin/${CAMNAME} &
  ulimit -s 1024 	
  #/usr/bin/oscamicam -b -c /etc/tuxbox/config/oscamicam
  # Setze den Statuscode auf 0
	STATUS=1
    CAM_UP_OUTPUT="$(/usr/bin/oscamicam -b -c /etc/tuxbox/config/oscamicam 2>&1)"
	STATUS=$?  # Setze den Statuscode basierend auf dem Ausführungsstatus des Befehls
	echo "cam start gestartet befehl " >> $LOG_FILE
	echo "CAM_UP_OUTPUT: $CAM_UP_OUTPUT" >> $LOG_FILE
    echo "cam start gestartet befehl CAM_UP_OUTPUT " >> $LOG_FILE
	echo "Statuscode: $STATUS" >> $LOG_FILE
	#wget -O -q "http://localhost/web/message?text=das+ist+ein+test&type=2&timeout=1" /dev/null     # den musste ich machen damit der fehler angezeigt wird , ERROR_MESSAGE kommt sonst nicht
	#sleep 5	
	if [ $STATUS -gt 0 ]; then
		echo "cam start gestartet error message " >> $LOG_FILE
		ERROR_MESSAGE="Fehler beim Starten der Oscam: $CAM_UP_OUTPUT"
		echo "$ERROR_MESSAGE" >> $LOG_FILE
		#wget -O -q "http://localhost/web/message?text=$ERROR_MESSAGE&type=2&timeout=5" /dev/null
		#sleep 1  # Warte eine kurze Zeit, damit die Ausgabe in die Datei geschrieben wird
		echo "cam start error mesage ausgabe ende " >> $LOG_FILE
		$WGET -O -q "http://localhost/web/message?text=${MESSAGE// /%20}&type=0&timeout=5" /dev/null
		sleep 3
		$WGET -O -q "http://localhost/web/message?text=Cam+not+Startet+Error!!!+---+logfile+---+tmp/OscamStartError.log&type=1&timeout=10" /dev/null
		sleep 10
	
	fi






  echo "cam start ende" >> $LOG_FILE	
  ;;
stop)
  echo "cam stop befehl " >> $LOG_FILE
  echo "[SCRIPT] $1: $CAMNAME"
  killall -9 ${CAMNAME} 2>/dev/null
  remove_tmp
  ;;
restart)
  $0 stop
  sleep 2
  $0 start
  exit
  ;;
*)
  $0 stop
  exit 0
  ;;
esac

exit 0
