#!/bin/sh

LOG_FILE="/tmp/camstart.log"
OSD="Oscamicam"
CAM="oscamicam"
PID=`pidof $CAM`
Action=$1

cam_clean () {
		rm -rf /tmp/*.info* /tmp/.ncam /tmp/*.pid
}

cam_handle () {
		if test	-z "${PID}"	; then
				cam_up;
		else
				cam_down;
		fi;
}

cam_down ()	{
		echo "cam stop " >> $LOG_FILE
		killall	-9 oscamicam		
		sleep 2
		cam_clean
}

cam_up () {
				echo "cam start " >> $LOG_FILE
                #/usr/bin/oscamicam -c /etc/tuxbox/config/oscamicam &
				CAM_UP_OUTPUT="$(/usr/bin/oscamicam -c /etc/tuxbox/config/oscamicam 2>&1)"
    
					if [ $? -gt 0 ]; then
						ERROR_MESSAGE="Fehler beim Starten der Oscam: $CAM_UP_OUTPUT"
						echo "$ERROR_MESSAGE" >> $LOG_FILE
						$WGET -O -q "http://localhost/web/message?text=${MESSAGE// /%20}&type=0&timeout=5" /dev/null
						sleep 3
						$WGET -O -q "http://localhost/web/message?text=Cam+not+Startet+Error!!!+---+logfile+---+tmp/OscamStartError.log&type=1&timeout=10" /dev/null
						sleep 10
					fi
					echo "cam start ende " >> $LOG_FILE
}

if test	"$Action" =	"cam_startup" ;	then
	if test	-z "${PID}" ; then
		cam_down
		cam_up
	else
		echo "$CAM already running, exiting..."
	fi
elif test	"$Action" =	"cam_res" ;	then
		cam_down
		cam_up
elif test "$Action"	= "cam_down" ; then
		cam_down
elif test "$Action"	= "cam_up" ; then
		cam_up
else
		cam_handle
fi

exit 0
