#!/bin/sh


file_path="/tmp/CCcam.cfg"
#oscam_server_file_path="/tmp/oscam.server"
oscam_server_file_path="/etc/tuxbox/config/oscam.server"
#oscam_server_file_path="/etc/tuxbox/config/oscamicam/oscam.server"


#echo "hier geht es los " 

if [ -e "$file_path" ]; then
    # Datei "CCcam.cfg" öffnen und Zeilen lesen
	echo "-----------------------        cccam.cfg exists in tmp       ---------------------"
	while IFS= read -r line; do
        # Zeilen auf "C:" prüfen, um die relevante Zeile zu finden
        if echo "$line" | grep -q "^C:"; then
            parts=($line)
            if [ ${#parts[@]} -ge 4 ]; then
                ip_address="${parts[1]}"
                port="${parts[2]}"
                user="${parts[3]}"
                password="${parts[4]:-}"  # Wenn Passwort vorhanden, setzen
            fi
            break  # Die relevante Zeile wurde gefunden, daher die Schleife beenden
        fi
    done < "$file_path"

    new_device="$ip_address,$port"
	new_user="$user"
	new_password="$password"
	echo "device: $new_device"
	echo "user: $new_user"
	echo "password: $new_password"
	
    # Ausgabe der extrahierten Informationen	

else	
	echo "-----------------------       cccam.cfg not exists in tmp    ---------------------"
	exit 0
fi

if [ -e "$oscam_server_file_path" ]; then
	echo "-----------------------          oscam.server exists         ---------------------"

else	
	echo "-----------------------    oscam.server not exists in tmp    ---------------------"
	exit 0
fi
echo "-----------------------          oscam.server Update         ---------------------"
tmp_file1="$oscam_server_file_path.txt"
rm -f "$tmp_file1"
# Variablen für die Aktualisierung
updated=false
				
oscamcccam=0
schongeschrieben=0
while IFS= read -r line; do
	echo "line: $line"
	#echo "tmp_file: $tmp_file"
	#echo "oscamcccam: $oscamcccam"
	if [[ "$line" == *oscamcccam* ]] || [[ $oscamcccam == 1 ]]; then
		oscamcccam=1
		#echo "----------------------- label gefunden ---------------------"
		updated=true
				
		if [[ "$line" == *device* ]]; then
			echo "----------------------- device new ---------------------"
			echo "device = $new_device" >> "$tmp_file1"
			echo "device = $new_device"
			schongeschrieben=1
		elif [[ "$line" == *password* ]]; then
			echo "----------------------- password new ---------------------"
			echo "password = $new_password" >> "$tmp_file1"
			echo "password = $new_password"
			schongeschrieben=1
		elif [[ "$line" == *user* ]]; then
			echo "----------------------- user new ---------------------"
			echo "user = $new_user" >> "$tmp_file1"
			echo "user = $new_user"
			schongeschrieben=1
				
	
		elif [ "$line" = "[reader]" ]; then
			#echo "----------------------- oscaccam auf 0 ---------------------"
			oscamcccam=0
		fi
	fi
			
			
	if [ "$oscamcccam" -eq 0 ]; then
		#echo "----------------------- zeile innere hinzufuegen ---------------------"
		# Füge die ursprünglichen Zeilen hinzu
		echo "$line" >> "$tmp_file1"
	else
		if [ "$schongeschrieben" == 0 ]; then
			#echo "----------------------- zeile hinzufuegen ---------------------"
			# Füge die ursprünglichen Zeilen hinzu
			echo "$line" >> "$tmp_file1"
		else
			#echo "----------------------- zeile schon geschrieben ---------------------"
			schongeschrieben=0
		fi
	fi
			
done < "$oscam_server_file_path"
# Schließe die temporäre Datei
exec 3>&-
#echo "update = $updated"	
if [ "$updated" = true ]; then
	#echo "Der Abschnitt 'oscamcccam' wurde gefunden. Aktualisierung wird durchgeführt."
	cp -pr "$oscam_server_file_path" "$oscam_server_file_path.old"
	cp -pr "$tmp_file1" "$oscam_server_file_path"
	rm -f "$tmp_file1"
	echo "----------------------- Update OK - Reload Readers in Readers ---------------------"
	#reload_readerdb();
else
	echo "Der Abschnitt 'oscamcccam' wurde nicht gefunden. Keine Aktualisierung durchgeführt."
	rm -f "$tmp_file1"
	echo "----------------------- Abschnitt nicht gefunden ---------------------"
fi


#exit 0
