#!/bin/sh


file_path="/tmp/oscam.server"
#oscam_server_file_path="/tmp/oscam.server"
#oscam_server_file_path="/etc/tuxbox/config/oscam.server"
oscam_server_file_path="/etc/tuxbox/config/oscamicam/oscam.server"
#oscam_server_file_path="/usr/cam/oscamicam/oscam.server"


#echo "hier geht es los " 

if [ -e "$file_path" ]; then
    # Datei "oscam.server" öffnen und Zeilen lesen
	echo "-----------------------        oscam.server exists in tmp       ---------------------"
	while IFS= read -r line; do
	#echo "line: $line"
	
		if echo "$line" | grep -q "protocol\s*=\s*"; then
        # Den Inhalt nach dem Gleichheitszeichen extrahieren und führende/trailing Leerzeichen entfernen
			new_protocol=$(echo "$line" | awk -F "=" '{print $2}' | awk '{$1=$1};1')
			echo "----------------------- protocol new ---------------------"
			echo "protocol = $new_protocol"	
		elif [[ "$line" == *device* ]]; then
        # Den Inhalt nach dem Gleichheitszeichen extrahieren und führende/trailing Leerzeichen entfernen
			new_device=$(echo "$line" | awk -F "=" '{print $2}' | awk '{$1=$1};1')
			echo "----------------------- device new ---------------------"
			echo "device = $new_device"
			
		elif echo "$line" | grep -q "password\s*=\s*"; then
        # Den Inhalt nach dem Gleichheitszeichen extrahieren und führende/trailing Leerzeichen entfernen
			new_password=$(echo "$line" | awk -F "=" '{print $2}' | awk '{$1=$1};1')
			echo "----------------------- password new ---------------------"
			echo "password = $new_password"
			
		elif echo "$line" | grep -q "user\s*=\s*"; then
        # Den Inhalt nach dem Gleichheitszeichen extrahieren und führende/trailing Leerzeichen entfernen
			new_user=$(echo "$line" | awk -F "=" '{print $2}' | awk '{$1=$1};1')
			echo "----------------------- user new ---------------------"
			echo "user = $new_user"

		fi		
	
		
			
done < "$file_path"
# Schließe die temporäre Datei
exec 3>&-

    #new_device="$ip_address,$port"
	#new_user="$user"
	#new_password="$password"
	echo "device: $new_device"
	echo "user: $new_user"
	echo "password: $new_password"
	echo "protocol: $new_protocol"
	
    # Ausgabe der extrahierten Informationen	

else	
	echo "-----------------------       oscam.server not exists in tmp    ---------------------"
	exit 0
fi

if [ -e "$oscam_server_file_path" ]; then
	echo "-----------------------          oscam.server exists         ---------------------"

else	
	echo "-----------------------    oscam.server not exists in tmp    ---------------------"
	exit 0
fi
echo "-----------------------          oscam.server Update         ---------------------"
tmp_file1="$oscam_server_file_path.txt"
rm -f "$tmp_file1"
# Variablen für die Aktualisierung
updated=false
				
oscamcccam=0
schongeschrieben=0
while IFS= read -r line; do
	#echo "device: $new_device"
	#echo "user: $new_user"
	#echo "password: $new_password"
	#echo "line: $line"
	#echo "tmp_file: $tmp_file1"
	#echo "oscamcccam: $oscamcccam"
	if [[ "$line" == *icam ]] || [[ $oscamcccam == 1 ]]; then
		oscamcccam=1
		#echo "----------------------- label gefunden ---------------------"
		updated=true
		if [[ "$line" == *protocol* ]]; then
			echo "----------------------- protocol new ---------------------"
			echo "protocol = $new_protocol" >> "$tmp_file1"
			echo "protocol = $new_protocol"
			schongeschrieben=1		
		elif [[ "$line" == *device* ]]; then
			echo "----------------------- device new ---------------------"
			echo "device = $new_device" >> "$tmp_file1"
			#echo "device = $new_device"
			schongeschrieben=1
		elif [[ "$line" == *password* ]]; then
			echo "----------------------- password new ---------------------"
			echo "password = $new_password" >> "$tmp_file1"
			#echo "password = $new_password"
			schongeschrieben=1
		elif [[ "$line" == *user* ]]; then
			echo "----------------------- user new ---------------------"
			echo "user = $new_user" >> "$tmp_file1"
			echo "user = $new_user"
			schongeschrieben=1
		
				
	
		elif [ "$line" = "[reader]" ]; then
			#echo "----------------------- oscaccam auf 0 ---------------------"
			oscamcccam=0
		fi
	fi
			
			
	if [ "$oscamcccam" -eq 0 ]; then
		#echo "----------------------- zeile innere hinzufuegen ---------------------"
		# Füge die ursprünglichen Zeilen hinzu
		echo "$line" >> "$tmp_file1"
	else
		if [ "$schongeschrieben" == 0 ]; then
			#echo "----------------------- zeile hinzufuegen ---------------------"
			# Füge die ursprünglichen Zeilen hinzu
			echo "$line" >> "$tmp_file1"
		else
			#echo "----------------------- zeile schon geschrieben ---------------------"
			schongeschrieben=0
		fi
	fi
			
done < "$oscam_server_file_path"
# Schließe die temporäre Datei
exec 3>&-
#echo "update = $updated"	
if [ "$updated" = true ]; then
	#echo "Der Abschnitt 'oscamcccam' wurde gefunden. Aktualisierung wird durchgeführt."
	cp -pr "$oscam_server_file_path" "$oscam_server_file_path.old"
	cp -pr "$tmp_file1" "$oscam_server_file_path"
	rm -f "$tmp_file1"
	echo "----------------------- Update OK - Reload Readers in Readers ---------------------"
	#reload_readerdb();
else
	#echo "Der Abschnitt 'oscamcccam' wurde nicht gefunden. Keine Aktualisierung durchgeführt."
	rm -f "$tmp_file1"
	#echo "----------------------- Abschnitt nicht gefunden ---------------------"
fi


#exit 0
