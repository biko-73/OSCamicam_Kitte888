#!/bin/sh
### BEGIN INIT INFO
# Provides:          softcam
# Required-Start:    $local_fs
# Required-Stop:     
# Should-Start:      $time $remote_fs cardserver
# Should-Stop:     
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: oscam
# Description:       oscam SoftCAM, card reader and server.
### END INIT INFO

LOGDIR="/tmp"
LOGFILE=$LOGDIR/OscamTestLogKitte888.log
#Generelles Logging.
exec 3>&1 4>&2
trap 'exec 2>&4 1>&3' 0 1 2 3

echo " hier geht es los " >> $LOGFILE

readlink $0 > /dev/null 2>&1 && CAM=$(basename $(readlink $0) | sed s#^softcam\.##)

[ -z "$CAM" ] && CAM=$(basename $0 | sed s#^softcam\.##)

if [ -z "$CAM" -o "$CAM" == "softcam" ]; then
	echo " if " >> $LOGFILE
    unset CAM
    for TESTCAM in oscamicam
	    do
        [ -x /usr/bin/$TESTCAM ] && CAM=$TESTCAM && break
    done
fi

[ -n "$CAM" ] || exit 1
[ -x /usr/bin/$CAM ] || exit 1

PIDFILE=/var/tmp/${CAM}.pid
DESC="Softcam service $CAM"
DAEMON=/usr/bin/$CAM
echo " hier geht es los 2 " >> $LOGFILE
echo " hier parameter " >> $LOGFILE
echo " $PIDFILE " >> $LOGFILE
echo " $DESC " >> $LOGFILE
echo " $DAEMON" >> $LOGFILE
echo " $CAM" >> $LOGFILE

case "$1" in
    start)
		echo " start " >> $LOGFILE
        if [ -e $PIDFILE ]; then
			      echo " pidfile " >> $LOGFILE
            PIDDIR=/proc/$(cat $PIDFILE)
            if [ -d ${PIDDIR} ] && [[ $(readlink -f ${PIDDIR}/exe) == $DAEMON ]]; then
                echo "$DESC already started; not starting."
                exit 1
            else
				        echo " rm pidfile " >> $LOGFILE
                rm -f $PIDFILE
            fi
        fi
        echo -n "Starting $DESC: "
		    echo " starting desc " >> $LOGFILE
        ulimit -s 1024
        $DAEMON --config-dir /etc/tuxbox/config/oscamicam --daemon --pidfile $PIDFILE --restart 2
        sleep 0.5
        RETVAL=1
        [ -e $PIDFILE ] && RETVAL=0
		echo " $RETVAL  " >> $LOGFILE
        if [ "$RETVAL" -eq "0" ]; then
			      echo " retval ok " >> $LOGFILE
            echo "OK"
        else
			      echo " retval fail " >> $LOGFILE
            echo "FAILED"
        fi
        exit $RETVAL
        ;;
    stop)
		    echo " stop " >> $LOGFILE
        echo -n "Stopping $DESC: "
        kill `cat $PIDFILE 2> /dev/null` 2> /dev/null
        RETVAL=$?
        if [ "$RETVAL" -eq "0" ]; then
			      echo " retval ok " >> $LOGFILE
            echo "OK"
        else
			      echo " retval fail " >> $LOGFILE
            echo "FAILED"
        fi
        sleep 1
        killall $CAM 2> /dev/null
        exit $RETVAL
        ;;
    restart|reload)
		    echo " restart stop " >> $LOGFILE
        $0 stop
        sleep 1
		    echo " restart start " >> $LOGFILE
        $0 start
        exit $?
        ;;
    version)
		    echo " verion " >> $LOGFILE
        $CAM -V | grep 'Version\|IPv6' | sed 's/Version:[ ]*//' | sed 's/IPv6.*yes/with IPv6/g' | sed 's/IPv6.*no/IPv4-only/g' | sed ':a;N;$!ba;s/\n/ /g'
        ;;
    info)
		    echo " info " >> $LOGFILE
        $CAM -V | grep 'Version\|IPv6' | sed 's/Version:[ ]*//' | sed 's/IPv6.*yes/with IPv6/g' | sed 's/IPv6.*no/IPv4-only/g' | sed ':a;N;$!ba;s/\n/ /g'
        ;;
    *)
        echo "Usage: $0 start|stop|restart"
        exit 1
        ;;
esac
exit 0
