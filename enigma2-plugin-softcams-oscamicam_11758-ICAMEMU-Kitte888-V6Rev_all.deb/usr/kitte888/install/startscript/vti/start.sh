#!/bin/sh
########################################
######     Powered by LINUXSAT    ######
########################################

CAMNAME="oscamicam"
LOG_FILE="/tmp/camstart.log"

remove_tmp () {
  rm -rf /tmp/cainfo.* /tmp/camd.* /tmp/sc.* /tmp/*.info* /tmp/*.tmp*
        [ -e /tmp/.emu.info ] && rm -rf /tmp/.emu.info
        [ -e /tmp/oscamicam.mem ] && rm -rf /tmp/oscamicam.mem
}

case "$1" in
  start)
  echo "cam start " >> $LOG_FILE
  echo "[SCRIPT] $1: $CAMNAME" >> $LOG_FILE
  remove_tmp
  touch /tmp/.emu.info
  echo $CAMNAME > /tmp/.emu.info
  /usr/bin/oscamicam -b -r 2 -c /etc/tuxbox/config/oscamicam  &

  #STATUS=1
  #CAM_UP_OUTPUT="$(/usr/bin/$CAMNAME --daemon --config-dir /etc/tuxbox/config/$CAMNAME --pidfile /tmp/cam.pid --restart 2 --utf8 2>&1)"
  #STATUS=$?  # Setze den Statuscode basierend auf dem Ausführungsstatus des Befehls
  #echo "cam start gestartet befehl " >> $LOG_FILE
  #echo "CAM_UP_OUTPUT: $CAM_UP_OUTPUT" >> $LOG_FILE
  #echo "cam start gestartet befehl CAM_UP_OUTPUT " >> $LOG_FILE
  #echo "Statuscode: $STATUS" >> $LOG_FILE
  #$WGET -O -q "http://localhost/web/message?text=das+ist+ein+test&type=1&timeout=1" /dev/null     # den musste ich machen damit der fehler angezeigt wird , ERROR_MESSAGE kommt sonst nicht
  #sleep 1



  #if [ $STATUS -gt 0 ]; then
#		echo "cam start gestartet error message " >> $LOG_FILE
#		ERROR_MESSAGE="Fehler beim Starten der Oscam: $CAM_UP_OUTPUT"
#		echo "$ERROR_MESSAGE" >> $LOG_FILE
#		$WGET -O -q "http://localhost/web/message?text=${MESSAGE// /%20}&type=0&timeout=5" /dev/null
#		sleep 3
#		$WGET -O -q "http://localhost/web/message?text=Cam+not+Startet+Error!!!+---+logfile+---+tmp/OscamStartError.log&type=1&timeout=10" /dev/null
#		sleep 10
#		echo "cam start error mesage ausgabe ende " >> $LOG_FILE
		
	
# fi
  echo "cam start ende" >> $LOG_FILE 



  ;;
  stop)
  echo "cam start " >> $LOG_FILE	
  echo "[SCRIPT] $1: $CAMNAME"
  kill `pidof ncam`
  killall -9 oscamicam  2>/dev/null
  remove_tmp
  ;;
  restart)
  $0 stop
  sleep 2
  $0 start
  exit
  ;;
  *)
  $0 stop
  exit 0
  ;;
esac

exit 0
