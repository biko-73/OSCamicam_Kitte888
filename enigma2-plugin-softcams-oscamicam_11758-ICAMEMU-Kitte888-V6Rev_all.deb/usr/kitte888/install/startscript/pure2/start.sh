#!/bin/sh
########################################
######      Powred by RAED        ######
########################################

LOG_FILE="/tmp/camstart.log"
OSD="oscamicam"
PID=$(pidof $OSD) 
Action=$1




cam_clean () {
		rm -rf /tmp/*.info* /tmp/.*cam /tmp/*.pid
}

cam_handle () {
		if test	-z "${PID}"	; then
				cam_up;
		else
				cam_down;
		fi;
}

cam_down ()	{
		echo "cam stop befehl " >> $LOG_FILE
		killall	-9 ${OSD}
		
		sleep 2
		cam_clean
}

cam_up () {
		echo "cam start " >> $LOG_FILE	
			

		/usr/bin/cam/${OSD} -b -r 2 -c /etc/tuxbox/config/${OSD} &

		# Setze den Statuscode auf 0
		#STATUS=1
		#CAM_UP_OUTPUT="$(/usr/bin/cam/${OSD} -b -r 2 -c /etc/tuxbox/config/${OSD} 2>&1)"
		#STATUS=$?  # Setze den Statuscode basierend auf dem Ausführungsstatus des Befehls
		#echo "cam start gestartet befehl " >> $LOG_FILE
		#echo "CAM_UP_OUTPUT: $CAM_UP_OUTPUT" >> $LOG_FILE
		#echo "cam start gestartet befehl CAM_UP_OUTPUT " >> $LOG_FILE
		#echo "Statuscode: $STATUS" >> $LOG_FILE
		#wget -O -q "http://localhost/web/message?text=das+ist+ein+test&type=2&timeout=1" /dev/null     # den musste ich machen damit der fehler angezeigt wird , ERROR_MESSAGE kommt sonst nicht
		#sleep 5	
		#if [ $STATUS -gt 0 ]; then
		#	echo "cam start gestartet error message " >> $LOG_FILE
		#	ERROR_MESSAGE="Fehler beim Starten der Oscam: $CAM_UP_OUTPUT"
		#	echo "$ERROR_MESSAGE" >> $LOG_FILE
		#	$WGET -O -q "http://localhost/web/message?text=${MESSAGE// /%20}&type=0&timeout=5" /dev/null
		#	sleep 3
		#	$WGET -O -q "http://localhost/web/message?text=Cam+not+Startet+Error!!!+---+logfile+---+tmp/OscamStartError.log&type=1&timeout=10" /dev/null
		#	sleep 10
		#	echo "cam start error mesage ausgabe ende " >> $LOG_FILE
			
		
		#fi
		
		echo "cam start ende " >> $LOG_FILE	
}

if test	"$Action" =	"cam_startup" ;	then
	if test	-z "${PID}" ; then
		cam_down
		cam_up
	else
		echo "$CAM already running, exiting..."
	fi
elif test	"$Action" =	"cam_res" ;	then
		cam_down
		cam_up
elif test "$Action"	= "cam_down" ; then
		cam_down
elif test "$Action"	= "cam_up" ; then
		cam_up
else
		cam_handle
fi

exit 0
