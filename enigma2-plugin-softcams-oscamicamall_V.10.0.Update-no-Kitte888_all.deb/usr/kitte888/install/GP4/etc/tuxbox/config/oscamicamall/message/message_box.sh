#!/usr/bin/env python2
# -*- coding: utf-8 -*-


import urllib
import urllib2
import re
import os
import sys
import time
import logging
import xml.etree.ElementTree as ET
# im NN2 geht sie

try:
    # Python 3
    from urllib import request
    from urllib.error import URLError
except ImportError:
    # Python 2
    import urllib2 as request
    import urllib2
    from urllib import quote  # URL-Encoding für Python 2
    from urllib2 import URLError  # URLError für Fehlerbehandlung



BOXIP = "http://localhost"
LOGDIR = "/tmp"
LOGFILE = os.path.join(LOGDIR, "kitte888_message_box.log")
ANSWER_FILE = "/tmp/message_answer.txt"

file_path = "/tmp/yesno"
# Logging einrichten
logging.basicConfig(filename=LOGFILE, level=logging.INFO, format='%(asctime)s - %(message)s')
logging.info("**************************** START *******************************")
# Überprüfen der Anzahl der Argumente
if len(sys.argv) != 4:
    print("Usage: {} <message> <type> <timeout>".format(sys.argv[0]))
    sys.exit(1)

# Argumente zuweisen
message = sys.argv[1]  # Die Nachricht bleibt unverändert
messagetype = sys.argv[2]
messagezeit = sys.argv[3]

logging.info("**************************** show message *******************************")
logging.info(str(message))
logging.info(str(messagetype))
logging.info(str(messagezeit))


# Zeilen für die Nachricht definieren
header = "\n                                                      \n"  # Zeile vor der Nachricht
message=message
footer = "\n\n\n\n************************************************\n"   # Zeile nach der Nachricht

# Nachricht anpassen
formatted_message = "{}{}{}".format(header, message, footer)
print(formatted_message)

# Session-ID abrufen
session_url = "http://localhost/web/session"
response = urllib2.urlopen(session_url)
session_data = response.read()

# Session-ID extrahieren
session_id_match = re.search(r"<e2sessionid>(.*?)</e2sessionid>", session_data)
if not session_id_match:
    print("Fehler beim Abrufen der Session-ID.")
    sys.exit(1)

session_id = session_id_match.group(1)

# Nachricht senden
message_url = "http://localhost/web/message"
data = {
    'text': formatted_message,  # Die Nachricht wird nicht kodiert
    'type': messagetype,
    'timeout': messagezeit,
    'sessionid': session_id
}
data_encoded = urllib.urlencode(data)

try:
    request = urllib2.Request(message_url, data_encoded)
    request.add_header("Content-Type", "application/x-www-form-urlencoded")
    response = urllib2.urlopen(request)
    print("Nachricht gesendet: {}".format(message))

    logging.info("messagetype ist : {}".format(messagetype))
    # Auf Antwort warten (bei type=0 erwartet Enigma2 eine Benutzeraktion)
    if messagetype == "0":
        logging.info("Warte auf Benutzerantwort...")

        # Löschen der Datei yesno
        if os.path.exists(file_path):
            os.remove(file_path)
            logging.info("Datei {} wurde geloescht.".format(file_path))

        answer = "no"  # Standardantwort

        timeout2 = int(messagezeit) - 1  # Sicherheitspuffer
        abfragen_count = 0

        while abfragen_count < timeout2:
            logging.info("Warte auf Benutzerantwort... Versuch {}/{}".format(abfragen_count + 1, timeout2))

            answer_url = "{}/web/messageanswer".format(BOXIP)

            try:
                logging.info("Sende Anfrage an {}".format(answer_url))

                if sys.version_info[0] >= 3:
                    from urllib import request

                    answer_response = request.urlopen(answer_url)
                else:
                    answer_data = urllib.urlencode({'sessionid': session_id})
                    answer_request = urllib2.Request(answer_url, answer_data)
                    answer_request.add_header("Content-Type", "application/x-www-form-urlencoded")
                    answer_response = urllib2.urlopen(answer_request)

                response_content = answer_response.read().decode().strip()

                if response_content in ["yes", "no"]:
                    logging.info("Benutzer hat geantwortet: {}".format(response_content))
                    answer = response_content
                    break  # Antwort erhalten, Schleife beenden!

            except Exception as e:
                logging.error("Fehler beim Abrufen der Antwort: {}".format(e))

            # Falls Datei existiert, Antwort daraus holen
            if os.path.exists(file_path):
                logging.info("Antwortdatei {} gefunden!".format(file_path))
                with open(file_path, 'r') as file:
                    file_content = file.read().strip()

                if file_content in ["yes", "no"]:
                    logging.info("Antwort aus Datei: {}".format(file_content))
                    answer = file_content
                    break  # Antwort erhalten, Schleife beenden!

            abfragen_count += 1
            time.sleep(1.0)  # 1 Sekunde warten

        # Falls keine Antwort erhalten wurde, bleibt `answer = "no"`
        logging.info("Finale Antwort nach Timeout: {}".format(answer))

        # Antwort speichern
        try:
            with open(ANSWER_FILE, "w") as answer_file:
                logging.info("Speichere Antwort in {}: {}".format(ANSWER_FILE, answer))
                answer_file.write(answer)
        except Exception as e:
            logging.error("Fehler beim Schreiben der Antwortdatei: {}".format(e))

        # Antwort auch in file_path speichern
        try:
            with open(file_path, "w") as file:
                logging.info("Speichere Antwort in {}: {}".format(file_path, answer))
                file.write(answer)
        except Exception as e:
            logging.error("Fehler beim Schreiben der Datei {}: {}".format(file_path, e))


except urllib2.URLError as e:
    print("Fehler beim Senden der Nachricht: {}".format(e))