#!/bin/bash
#/etc/tuxbox/config/oscamicamall/binary/oscamicamall -b -B -r 2 -w 1 -c /etc/tuxbox/config/oscamicamall
/lib/systemd/system/softcam.all start
