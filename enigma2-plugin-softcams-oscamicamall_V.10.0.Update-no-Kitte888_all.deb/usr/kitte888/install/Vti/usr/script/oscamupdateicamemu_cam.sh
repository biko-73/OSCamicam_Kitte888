#!/bin/bash
CAMNAME="oscamupdateicamemu"

Action=$1

if test "$Action" = "start" ; then
	
	/usr/script/softcam start &
	sleep 4

    

elif test "$Action" = "stop" ; then

	/usr/script/softcam stop &
	sleep 4
    
    

elif test "$Action" = "restart" ; then
	/usr/script/softcam restart &
	sleep 4
    
        


        

else
    
    echo "Usage: $0 start|stop|restart"
    exit 1
    




fi
    
# so starten das vti keine zeit verliert und nicht das webif abschaltet weil es drauf wartet das es in der zeit startet
# & dadurch ist es hier fertig und die softcam startet im hintergrund
exit 0