#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import sys
import time
import logging
import xml.etree.ElementTree as ET
# Bedingte Imports für Python 2 und 3
try:
    # Python 3
    from urllib import request
    from urllib.error import URLError
except ImportError:
    # Python 2
    import urllib2 as request
    import urllib2
    from urllib import quote  # URL-Encoding für Python 2
    from urllib2 import URLError  # URLError für Fehlerbehandlung

#Logik für die Frage und Eingabe hier
#Wenn der Benutzer "ja" wählt:
#sys.exit(0)  # Rückgabewert für "ja"

#Wenn der Benutzer "nein" wählt:
#sys.exit(1)  # Rückgabewert für "nein"


# Konfiguration
BOXIP = "http://localhost"
LOGDIR = "/tmp"
LOGFILE = os.path.join(LOGDIR, "kitte888_message.log")
ANSWER_FILE = "/tmp/message_answer.txt"

file_path = "/tmp/yesno"
# Logging einrichten
logging.basicConfig(filename=LOGFILE, level=logging.INFO, format='%(asctime)s - %(message)s')
logging.info("**************************** START *******************************")

# Funktion zum Senden von Nachrichten
def show_message(message, messagetype, messagezeit):
    logging.info("**************************** show message *******************************")
    logging.info(str(message))
    logging.info(str(messagetype))
    logging.info(str(messagezeit))
    try:
        # hier abfrage is py3 version


        # Überprüfen, ob es Python 3 ist
        if sys.version_info[0] >= 3:
            from urllib import request
            from urllib.error import URLError
            logging.info("Das Skript wird in Python 3 ausgeführt.")
            url = "{}/web/message?text={}&type={}&timeout={}".format(
                BOXIP,
                message.replace(' ', '+'),
                messagetype,
                messagezeit
            )
            logging.info("Nachricht senden url: {}".format(url))
            response = request.urlopen(url)
            logging.info("Nachricht gesendet: {}".format(message))



        else:
            logging.info("Das Skript wird in Python 2 ausgeführt.")

            # so geht es in py2
            import urllib2
            from urllib import quote  # Füge dies hinzu
            from urllib2 import URLError  # URLError für Python 2 importieren
            #logging.info("message_zeit: {}".format(message_zeit))  # Debugging-Info
            #message_zeit = int(message_zeit) + 3  # Falls es eine ganze Zahl sein soll
            #message_type = int(message_type)

            #logging.info("message_zeit: {}".format(message_zeit))  # Debugging-Info

            #time.sleep(8)
            #REQUEST_TIMEOUT = 3

            # URL-kodieren der Nachricht
            encoded_message = quote(message)
            url = "{}/web/message?text={}&type={}&timeout={}".format(BOXIP, encoded_message, messagetype, messagezeit)

            logging.info("Aufgerufene URL: {}".format(url))  # Debugging-Info

            try:
                response = urllib2.urlopen(url)
                #response = urllib2.urlopen(url, timeout=REQUEST_TIMEOUT)
                logging.info("Nachricht gesendet PY2: {} mit Type {} Timeout {}".format(message, messagetype, messagezeit))
            except URLError as e:
                logging.error("Fehler beim Senden der Nachricht: {}".format(e))
                with open(ANSWER_FILE, "w") as answer_file:
                    answer_file.write("no")  # Standardantwort bei Fehler
                exit(1)

        logging.info("messagetype ist : {}".format(messagetype))
        # Auf Antwort warten (bei type=0 erwartet Enigma2 eine Benutzeraktion)
        if messagetype == "0":
            logging.info("Warte auf Benutzerantwort...")

             # Löschen der Datei yesno
            if os.path.exists(file_path):
                os.remove(file_path)
                logging.info("Datei {} wurde geloescht.".format(file_path))

            answer = None
            timeout = int(messagezeit)


            abfragen_count = 0

            while abfragen_count < timeout:
                logging.info("Warte auf Benutzerantwort schleife...")
                answer_url = "{}/web/messageanswer".format(BOXIP)
                try:
                    if sys.version_info[0] >= 3:
                        answer_response = request.urlopen(answer_url)
                        answer = answer_response.read().decode().strip()
                    else:
                        answer_response = urllib2.urlopen(answer_url)
                        answer = answer_response.read().strip()


                    if answer:
                        #logging.info("Antwort von Enigma2: {}".format(answer))
                        # Antwort parsen
                        logging.info("Antwort von Enigma2 answer ")
                        root = ET.fromstring(answer)
                        state = root.find("e2state").text
                        statetext = root.find("e2statetext").text

                        logging.info("Antwort-Status in answer: {}, Text: {}".format(state, statetext))

                        # Liste mit bekannten "Ja"-Antworten in verschiedenen Sprachen
                        yes_answers = {"yes", "ja", "oui", "sí", "sì", "sim", "да", "是", "はい", "نعم", "evet", "हाँ"}

                        if state == "True":  # Benutzer hat geantwortet
                            logging.info("Benutzer hat geantwortet answer: {}".format(statetext))


                            # Überprüfen, ob "JA" in statetext enthalten ist
                            if any(answer in statetext.lower() for answer in yes_answers):
                                print("Die Antwort lautet JA!")
                                answer = "yes"
                            else:
                                print("Die Antwort nein.")
                                answer = "no"
                            break

                except URLError as e:
                    logging.error("Fehler beim Abrufen der Antwort: {}".format(e))
                    answer = "no"
                except ET.ParseError as e:
                    logging.error("Fehler beim Parsen der Antwort: {}".format(e))
                    answer = "no"

                # Kurze Pause, bevor erneut geprüft wird
                abfragen_count += 1
                time.sleep(1.0)


                logging.info("Keine Antwort erhalten, Timeout abgelaufen.")
                answer = "no"  # Standardantwort bei Timeout

            # Antwort speichern
            with open(ANSWER_FILE, "w") as answer_file:
                logging.info("Antwort file öffnen")
                #logging.info("Antwort von Enigma2: {}".format(answer))
                answer_file.write(answer)
                # Antwort speichern
            with open(file_path, "w") as answer_file:
                logging.info("Antwort yesno file öffnen")
                #logging.info("Antwort von Enigma2: {}".format(answer))
                answer_file.write(answer)

    except Exception as e:
        logging.error("Fehler beim Senden der Nachricht: {}".format(e))
        with open(ANSWER_FILE, "w") as answer_file:
            answer_file.write("no")  # Standardantwort bei Fehler

if __name__ == "__main__":
    if len(sys.argv) != 4:
        logging.error("Usage: python script.py <message> <type> <timeout>")
        sys.exit(1)

    # Argumente auslesen
    MESSAGE = sys.argv[1]
    message_type = sys.argv[2]
    message_zeit = sys.argv[3]

    # Nachricht senden
    show_message(MESSAGE, message_type, message_zeit)
    sys.exit(0)  # Erfolgreich beendet