#!/usr/bin/env python
# -*- coding: utf-8 -*-

import logging
import subprocess
import os
import sys
import shutil
# Übergebener Oscam-Name (aus Argument)
oscamname = "oscamicamall"

# Konfiguration
TMP_BINARY = "/tmp/oscamicamall.new"
#BIN_DIR = "/etc/tuxbox/config/oscamicamall/binary"
BIN_DIR = "/etc/tuxbox/config/oscamicamall/binary/"
BACKUP_SUFFIX = ".old"
LOGFILE = "/tmp/kitte888_binary_update_tmp.log"

# Logging einrichten
logging.basicConfig(filename=LOGFILE, level=logging.INFO, format='%(asctime)s - %(message)s')
logging.info("**************************** START *******************************")

def check_binary():
	# Prüfen, ob ein Oscam-Name übergeben wurde
	if not oscamname:
		logging.error("Fehler: Kein Oscam-Name angegeben.")
		print("-----------------------        Keine Name der Binary      ---------------------")
		sys.exit(1)

	# Sicherstellen, dass die neue Binary existiert
	if not os.path.isfile(TMP_BINARY):
		logging.error("Fehler: Neue Oscam-Binary {} existiert nicht.".format(TMP_BINARY))
		print("-----------------------        Keine Binary gefunden       ---------------------")
		sys.exit(1)

	# Prüfen, ob die alte Binary existiert
	if not os.path.isfile(os.path.join(BIN_DIR, oscamname)):
		logging.error("Fehler: Alte Oscam-Binary ({}) existiert nicht.".format(os.path.join(BIN_DIR, oscamname)))
		print("-----------------------        es gibt keine Binary zum updaten       ---------------------")
		sys.exit(1)

	# Backup der alten Binary erstellen
	logging.info("Erstelle Backup für {}...".format(oscamname))
	old_binary = os.path.join(BIN_DIR, oscamname)
	logging.info("old binary {}...".format(old_binary))
	backup_binary = old_binary + BACKUP_SUFFIX
	logging.info("backup binary {}...".format(backup_binary))
	shutil.copy(old_binary, backup_binary)

	# Neue Binary mit mv sicher ersetzen
	logging.info("Ersetze Binary mit mv: {} -> {}".format(TMP_BINARY, old_binary))
	subprocess.call(["mv", TMP_BINARY, old_binary])

	os.chmod(os.path.join(BIN_DIR, oscamname), 0o755)  # Setze die Berechtigung

	logging.info("Oscam-Binary erfolgreich aktualisiert.")
	print("-----     version Copiert mache einen Neustart auf der Box    --------")



if __name__ == "__main__":
	check_binary()