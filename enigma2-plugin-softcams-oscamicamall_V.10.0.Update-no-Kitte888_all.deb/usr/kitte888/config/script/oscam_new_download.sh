#!/usr/bin/env python
# -*- coding: utf-8 -*-

# in console aufrufen oder aus einer shell
# /usr/bin/check_cam.sh
# schauen ob eine osam running ist und sie dann stoppen
import os
import shutil
import sys
import time
import requests


import subprocess
import logging
import requests
from shutil import copyfile
from os import remove
from os.path import isfile

# Konfiguration
LOGDIR="/tmp"
LOGFILE=os.path.join(LOGDIR, "kitte888_oscam_new_download.log")
cpuversion = ''
# Logging einrichten
logging.basicConfig(filename=LOGFILE, level=logging.INFO, format='%(asctime)s - %(message)s')
logging.info("**************************** START *******************************")
#########################################################################################################

def download_file(remote_urloscam, local_path):
	logging.info("download ")
	logging.info(remote_urloscam)
	logging.info(local_path)

	response = requests.get(remote_urloscam)

	logging.info("response1")
	if response.status_code == 200:
		logging.info("response2")
		expected_size = int(response.headers.get('content-length', 0))
		with open(local_path, "wb") as file:
			for chunk in response.iter_content(chunk_size=1024):
				file.write(chunk)

		# Überprüfe die Größe der heruntergeladenen Datei
		actual_size = os.path.getsize(local_path)

		if actual_size == expected_size:
			logging.info("Download abgeschlossen und Dateigröße stimmt ueberein.")
			source_path = "/etc/tuxbox/config/oscamicamall/binary/oscamicamall"
			destination_path = "/etc/tuxbox/config/oscamicamall/binary/oscamicamall.old"
			shutil.copy(source_path, destination_path)

			# neue Oscam copiere , aktuelle
			source_path = "/etc/tuxbox/config/oscamicamall/versionen/oscamicamall"
			destination_path = "/etc/tuxbox/config/oscamicamall/binary/oscamicamall"
			#shutil.copy(source_path, destination_path)

			subprocess.call(["mv", source_path, destination_path])

			logging.info("file copiert")


			print("-----     version Copiert mache einen Neustart auf der Box    --------")
			#subprocess.run(["chmod", "+x", destination_path], check=True)		#py3
			subprocess.call(["chmod", "+x", destination_path])
			logging.info("rechte gesetzt ")
			
			
		else:
			logging.info("datei stimmt nicht ")
	
			
	else:
			
		logging.info("kein download")	
	
#########################################################################################################
def cpu_info():
	print("80 -----------------------        Cpu Version        ---------------------")
	logging.info("welche cpu holen vom script")
	process = subprocess.Popen(
	['python', '/etc/tuxbox/config/oscamicamall/scripte/cpu.sh'],
		 stdout=subprocess.PIPE, stderr=subprocess.PIPE
	)

	# Ausgabe lesen und aufbereiten
	stdout, stderr = process.communicate()

	# Umwandlung von Bytestring zu normalem String
	output = stdout.decode('utf-8').strip()  # Hier wird die Byte-Daten in ein UTF-8-String dekodiert
	logging.info("cpu : {}".format(output))
	model_name = output
	print("cpu : {}".format(output))
	# Überprüfe den Typ basierend auf der Modellbezeichnung
	if 'armv' in model_name.lower():
		cpuversion = 'arm'
		print("armv")
	elif 'arm' in model_name.lower():
		cpuversion = 'arm'
		print("arm")
	elif 'mips' in model_name.lower():
		cpuversion = 'mipsel'
		print("mipsel")
	elif 'aarch' in model_name.lower():
		cpuversion = 'aarch'
		print("aarch")
	logging.info("CPU-Info von der box: " + cpuversion)
	print("109 -----------------------        Cpu Version: {}        ---------------------".format(cpuversion))

def update_version():
	logging.info("Download oscam schauen welche cpu")
	print("-----------------------        Download Version         ---------------------")
	# ------------------------------------------ hier wo es reincopiert wird ---------------------------
	local_path = "/etc/tuxbox/config/oscamicamall/versionen/oscamicamall"
	cpu_path = "/etc/tuxbox/config/oscamicamall/versionen/cpu"
	remote_urloscam = "https://magentacloud.de/s/dBmmC8JEjiyYTy8/download?path=%2F&files=oscamarm"
	# --------------------------------------------------------------------------------------------------
	# Datei, die die CPU-Informationen enthält


	logging.info("welche cpu holen vom script")
	process = subprocess.Popen(
	['python', '/etc/tuxbox/config/oscamicamall/scripte/cpu.sh'],
		 stdout=subprocess.PIPE, stderr=subprocess.PIPE
	)

	# Ausgabe lesen und aufbereiten
	stdout, stderr = process.communicate()

	# Umwandlung von Bytestring zu normalem String
	output = stdout.decode('utf-8').strip()  # Hier wird die Byte-Daten in ein UTF-8-String dekodiert
	logging.info("cpu : {}".format(output))
	model_name = output
	print("135 -----------------------        Cpu Version         ---------------------")
	cpuversion = ""
	# Überprüfe den Typ basierend auf der Modellbezeichnung
	if 'armv' in model_name.lower():
		cpuversion = 'arm'
	elif 'arm' in model_name.lower():
		cpuversion = 'arm'
	elif 'mips' in model_name.lower():
		cpuversion = 'mipsel'
	elif 'aarch' in model_name.lower():
		cpuversion = 'aarch'
	logging.info("146  CPU-Info von der box: ")
	logging.info(cpuversion)
	logging.info("148 CPU- download url suchen fuer: ")
	print("149 -----------------------  Cpu ---------------------")
	print(cpuversion)
	if cpuversion == "arm" :
		logging.info("cpu ist eine arm ")
		remote_urloscam = "https://magentacloud.de/s/dBmmC8JEjiyYTy8/download?path=%2F&files=oscamarm"
	else:
	
		if  cpuversion == "mipsel" :
			logging.info("cpu ist eine mipsel")
			remote_urloscam = "https://magentacloud.de/s/dBmmC8JEjiyYTy8/download?path=%2F&files=oscammipsel"

		else:
		
			if  cpuversion == "aarch" :
				logging.info("cpu ist eine aarch")
				remote_urloscam = "https://magentacloud.de/s/dBmmC8JEjiyYTy8/download?path=%2F&files=oscamaarch"
			else:
				logging.info("cpu fehler nicht gefunden")
			
	if cpuversion != "none" : 
		download_file(remote_urloscam, local_path)
	else:
		logging.info("cpu info nicht vorhanden kein download ")
		
if __name__ == "__main__":
    update_version()
