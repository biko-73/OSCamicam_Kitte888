#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import time
import requests
import urllib3
from datetime import datetime

# testen in der console
# python /etc/tuxbox/config/oscamicamall/scripte/zeit.py


# Warnungen deaktivieren
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

import logging


# Konfiguration
BOXIP = "http://localhost"
LOGDIR = "/tmp"
LOGFILE = os.path.join(LOGDIR, "kitte888_zeit.log")

# Logging einrichten
logging.basicConfig(filename=LOGFILE, level=logging.INFO, format='%(asctime)s - %(message)s')
logging.info("**************************** START *******************************")

def get_current_time():
    logging.info("**************************** get current")
    return time.strftime('%Y-%m-%d %H:%M:%S')

def is_older_than_2025(current_time):
    logging.info("**************************** is older than 2025")
    threshold = datetime(2025, 1, 1)
    current_datetime = datetime.strptime(current_time, '%Y-%m-%d %H:%M:%S')
    return current_datetime < threshold



def fetch_time_from_internet():
    logging.info("**************************** fetch time from internet")
    """ Holt die exakte UTC-Zeit aus dem Internet mit Fallback-Mechanismus """
    urls = [
        # Beste & schnellste zuerst
        ('https://worldtimeapi.org/api/timezone/Etc/UTC', lambda r: r['utc_datetime']),
        ('https://timeapi.io/api/Time/current/zone?timeZone=UTC', lambda r: r['dateTime']),

    ]

    for url, extractor in urls:
        try:
            response = requests.get(url, timeout=5, verify=False)
            if response.status_code == 200:
                data = response.json()
                return extractor(data)
            else:
                logging.info("Fehler beim Abrufen der Zeit von {}: Status {}".format(url, response.status_code))
        except requests.RequestException as e:
            logging.info("Fehler beim Abrufen der Zeit von {}: {}".format(url, e))


    logging.warning("Zeitquellen nicht erreichbar. Fallback auf 01.01.2025 01:11.")
    return "2025-01-01T01:11:00"


def set_system_time(new_time):
    """ Setzt die exakte Systemzeit """
    try:
        # Millisekunden und "Z" entfernen, falls vorhanden
        clean_time = new_time.split('.')[0]  # Entfernt alles nach der Sekunde
        formatted_time = datetime.strptime(clean_time, '%Y-%m-%dT%H:%M:%S')
        time_str = formatted_time.strftime('%Y-%m-%d %H:%M:%S')

        os.system("date -s '{}'".format(time_str))
        logging.info("Systemzeit erfolgreich gesetzt auf: {}".format(time_str))

    except Exception as e:
        logging.info("Fehler beim Setzen der Systemzeit: {}".format(e))

if __name__ == "__main__":
    current_time = get_current_time()
    logging.info("Aktuelle Systemzeit: {}".format(current_time))

    if is_older_than_2025(current_time):
        logging.info("Die aktuelle Zeit ist aelter als 2025. Hole exakte Zeit aus dem Internet...")
        time.sleep(5) # warten netzwerk noch nicht da
        internet_time = fetch_time_from_internet()
        if internet_time:
            set_system_time(internet_time)  # Exakte Zeit setzen
    else:
        logging.info("Die aktuelle Zeit ist korrekt.")
        print("OK")


