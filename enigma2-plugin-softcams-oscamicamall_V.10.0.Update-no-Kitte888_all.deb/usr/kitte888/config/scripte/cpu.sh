#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import sys
import time
import logging


# Konfiguration
BOXIP = "http://localhost"
LOGDIR = "/tmp"
LOGFILE = os.path.join(LOGDIR, "kitte888_cpu.log")
ANSWER_FILE = "/tmp/oscam_answer.txt"

# Logging einrichten
logging.basicConfig(filename=LOGFILE, level=logging.INFO, format='%(asctime)s - %(message)s')
logging.info("**************************** START *******************************")
# Datei, die die CPU-Informationen enthält
check_file = '/proc/cpuinfo'  # oder der Pfad zu deiner

logging.info("CPU-Info neu holen von der box: ")
with open(check_file, 'r') as file:
    cpuinfo = file.read()
    logging.info("CPU-Info von der box: " + cpuinfo)

    # Suche nach der Modellbezeichnung
    model_name = "unbekannt"
    cpuversion = "none"
    for line in cpuinfo.splitlines():


        if 'model name' in line.lower():

            model_name = line.split(':', 1)[1].strip()
            logging.info("Modellbezeichnung: " + model_name)
            print(model_name)
            break
        if 'cpu model' in line.lower():

            cpu_model = line.split(':', 1)[1].strip()
            logging.info("Modellbezeichnung: " + cpu_model)
            print(cpu_model)
			
		if 'processor' in line.lower():

            cpu_model = line.split(':', 1)[1].strip()
            logging.info("Modellbezeichnung: " + cpu_model)
            print(cpu_model)


            break