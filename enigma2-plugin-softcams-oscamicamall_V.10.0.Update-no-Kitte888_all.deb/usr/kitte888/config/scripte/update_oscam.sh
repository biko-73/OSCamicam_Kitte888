#!/usr/bin/env python
# -*- coding: utf-8 -*-

# holt sich die version.new vom server und copiert sie nach version


import os
import subprocess
import logging
import requests

# Konfiguration
LOGDIR="/tmp"
LOGFILE=os.path.join(LOGDIR, "kitte888_update_oscam.log")

# Logging einrichten
logging.basicConfig(filename=LOGFILE, level=logging.INFO, format='%(asctime)s - %(message)s')
logging.info("**************************** START *******************************")


def download_file(remote_url, local_path):
    """
    Lädt eine Datei von einer Remote-URL herunter und speichert sie lokal ab.
    
    :param remote_url: Die URL der Datei.
    :param local_path: Der lokale Pfad, an dem die Datei gespeichert wird.
    :return: Der Inhalt der Datei als String, falls erfolgreich, sonst None.
    """
    logging.info("Starte Download: {}".format(remote_url))
    try:
        response = requests.get(remote_url, timeout=10)
        if response.status_code == 200:
            logging.info("Download erfolgreich, speichere Datei...")
            with open(local_path, "wb") as file:
                file.write(response.content)
            logging.info("Datei gespeichert: {}".format(local_path))
            
            with open(local_path, "r") as file:
                content = file.read().strip()
            return content
        else:
            logging.info("Fehler beim Download: Statuscode {}".format(response.status_code))
            return None
    except requests.RequestException as e:
        logging.info("Fehler bei der Anfrage: {}".format(e))
        return None

def update_version():
	
	# ------------------------------------------- hier path vom server wo es gehlot wird ---------------
    remote_url = "https://magentacloud.de/s/dBmmC8JEjiyYTy8/download?path=%2F&files=version.new"

	# ------------------------------------------ hier wo es reincopiert wird ---------------------------
    local_path = "/etc/tuxbox/config/oscamicamall/versionen/version.new"
	# --------------------------------------------------------------------------------------------------
	
    logging.info("Starte Versionsaktualisierung...")
    version_number = download_file(remote_url, local_path)

    if version_number:
        # Hier wird die GUI oder Logik aktualisiert
        logging.info("Neue Version gefunden: {}".format(version_number))
	
        print(version_number)
		
    else:
        logging.info("Fehler beim Herunterladen der neuen Version.")
        print("fehler download")

if __name__ == "__main__":
    update_version()
