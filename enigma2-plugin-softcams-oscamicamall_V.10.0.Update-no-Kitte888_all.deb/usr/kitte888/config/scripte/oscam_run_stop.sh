#!/usr/bin/env python
# -*- coding: utf-8 -*-

import logging
import subprocess
import os
import sys
# Konfiguration
LOGFILE = "/tmp/kitte888_oscam_run_stop.log"

# Logging einrichten
logging.basicConfig(filename=LOGFILE, level=logging.INFO, format='%(asctime)s - %(message)s')

# Logging einrichten
logging.info("**************************** START *******************************")

# Speicherort der Statusdatei
STATUS_FILE = "/tmp/kitte888_oscam_run_stop.txt"

def stop_process(oscam_name):
    try:
        # Stoppe den Prozess mit killall
        logging.info("Beende Oscam-Prozess: {}".format(oscam_name))
        subprocess.call(["killall", oscam_name])  # Für Python 2 und 3
        logging.info("{} wurde gestoppt.".format(oscam_name))
        print("Oscam {} wurde gestoppt.".format(oscam_name))
    except subprocess.CalledProcessError as e:
        logging.error("Fehler beim Stoppen des Oscam-Prozesses: {}".format(e))


def get_oscam_processes():
    """Sucht nach laufenden OSCam-Prozessen und speichert sie in eine Datei."""

    # Verwende Popen, um die Ausgabe zu erfassen
    process = subprocess.Popen(["ps", "-eo", "comm"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    # Warte auf das Ende des Prozesses und erfasse die Ausgabe
    stdout, stderr = process.communicate()

    # Konvertiere die Ausgabe in eine Zeichenkette (Python 2 und 3)
    if isinstance(stdout, bytes):
        stdout = stdout.decode('utf-8')  # Für Python 3
    else:
        stdout = stdout  # Für Python 2

    # Zeilen filtern: Nur Prozesse, deren Name mit "oscam" beginnt
    oscam_binaries = set(line.strip().rstrip(".") for line in stdout.splitlines() if line.strip().lower().startswith("oscam"))

    # Schreiben in die Datei
    with open(STATUS_FILE, "w") as f:
        for binary in sorted(oscam_binaries):
            f.write(binary.strip() + "\n")

    # Ausgabe der Ergebnisse
    if oscam_binaries:  # Überprüfen, ob das Set nicht leer ist
        print("vorhanden.")
        value = next(iter(oscam_binaries))
        print(value)
        oscam_name=value
        print(oscam_name)
        stop_process(oscam_name)
    else:
        print("Run_Stop : Keine Binarydateien vorhanden.")


if __name__ == "__main__":
    get_oscam_processes()