#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import sys
import time
import logging
import socket


# Konfiguration
BOXIP = "http://localhost"
LOGDIR = "/tmp"
LOGFILE = os.path.join(LOGDIR, "kitte888_ip.log")
ANSWER_FILE = "/tmp/oscam_answer.txt"

# Logging einrichten
logging.basicConfig(filename=LOGFILE, level=logging.INFO, format='%(asctime)s - %(message)s')
logging.info("**************************** START *******************************")

#import netifaces
# Hole die lokale IP-Adresse
#hostname = socket.gethostname()  # Name des Computers
#local_ip = socket.gethostbyname(hostname)  # IP-Adresse des Hosts
#logging.info("Lokale IP-Adresse: {}".format(local_ip))
#print("Lokale IP-Adresse: {}".format(local_ip))

# Wähle die Netzwerkschnittstelle, die du abfragen möchtest
#interface = 'eth0'  # Ethernet-Adapter, z.B. 'wlan0' für WLAN

# Hole die IP-Adresse der Schnittstelle
#ip_address = netifaces.ifaddresses(interface)[netifaces.AF_INET][0]['addr']



s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.settimeout(0)
try:
    # Versucht, mit einer externen IP-Adresse zu verbinden, um die lokale IP zu ermitteln
    s.connect(('10.254.254.254', 1))  # Du kannst auch eine andere öffentliche IP verwenden
    ip_address = s.getsockname()[0]  # Holt die lokale IP-Adresse
except Exception as e:
    print("Fehler beim Abrufen der IP-Adresse:", e)
    ip_address = None
finally:
    s.close()

logging.info("Lokale IP-Adresse: {}".format(ip_address))
print(ip_address)