#!/usr/bin/env python
# -*- coding: utf-8 -*-

# in console aufrufen oder aus einer shell
# /usr/bin/check_cam.sh
# schauen ob eine osam running ist und sie dann stoppen
import os
import shutil
import sys
import time
import requests


import subprocess
import logging
import requests
from shutil import copyfile
from os import remove
from os.path import isfile

# Konfiguration
LOGDIR="/tmp"
LOGFILE=os.path.join(LOGDIR, "kitte888_download_oscam.log")
cpuversion = ''
# Logging einrichten
logging.basicConfig(filename=LOGFILE, level=logging.INFO, format='%(asctime)s - %(message)s')
logging.info("**************************** START *******************************")
#########################################################################################################

def download_file(remote_urloscam, local_path):
    logging.info("download ")
    logging.info(remote_urloscam)
    logging.info(local_path)

    response = requests.get(remote_urloscam)

    logging.info("response1")
    if response.status_code == 200:
        logging.info("response2")
        expected_size = int(response.headers.get('content-length', 0))
        with open(local_path, "wb") as file:
            for chunk in response.iter_content(chunk_size=1024):
                file.write(chunk)

        # Überprüfe die Größe der heruntergeladenen Datei
        actual_size = os.path.getsize(local_path)
        if actual_size == expected_size:
            logging.info("Download abgeschlossen und Dateigröße stimmt überein.")

            try:
                # Alte Datei sichern
                source_path = "/etc/tuxbox/config/oscamicamall/binary/oscamicamall"
                destination_path = "/etc/tuxbox/config/oscamicamall/binary/oscamicamall.old"
                shutil.copy(source_path, destination_path)

                # Neue Datei kopieren
                source_path = "/etc/tuxbox/config/oscamicamall/versionen/oscamicamall"
                destination_path = "/etc/tuxbox/config/oscamicamall/binary/oscamicamall"
                shutil.copy(source_path, destination_path)
                logging.info("file kopiert")

                # Rechte setzen
                subprocess.call(["chmod", "+x", destination_path])
                logging.info("rechte gesetzt ")

                sys.exit(0)  # Erfolg
            except Exception as e:
                logging.error("Fehler beim Kopieren oder Rechte setzen: {}".format(e))
                sys.exit(1)  # Fehler beim Kopieren
        else:
            logging.error("Dateigröße stimmt nicht überein.")
            sys.exit(1)  # Datei unvollständig
    else:
        logging.error("Kein gültiger HTTP-Response (nicht 200).")
        sys.exit(1)  # Kein Download

#########################################################################################################

def update_version(cpuversion):
    logging.info("Download oscam schauen welche cpu")
    logging.info("CPU-Info von softcam uebergeben: " + cpuversion)
    # ------------------------------------------ hier wo es reincopiert wird ---------------------------
    local_path = "/etc/tuxbox/config/oscamicamall/versionen/oscamicamall"
    cpu_path = "/etc/tuxbox/config/oscamicamall/versionen/cpu"
    remote_urloscam = "https://magentacloud.de/s/dBmmC8JEjiyYTy8/download?path=%2F&files=oscamarm"
    # --------------------------------------------------------------------------------------------------



    # ---------------------------------------------------------------------------------------------------
    # Datei, die die CPU-Informationen enthält

    logging.info("CPU- download url suchen fuer: " + cpuversion)
    if cpuversion == "arm" :
        logging.info("cpu ist eine arm ")
        remote_urloscam = "https://magentacloud.de/s/dBmmC8JEjiyYTy8/download?path=%2F&files=oscamarm"
    else:

        if  cpuversion == "mipsel" :
            logging.info("cpu ist eine mipsel")
            remote_urloscam = "https://magentacloud.de/s/dBmmC8JEjiyYTy8/download?path=%2F&files=oscammipsel"

        else:

            if  cpuversion == "aarch" :
                logging.info("cpu ist eine aarch")
                remote_urloscam = "https://magentacloud.de/s/dBmmC8JEjiyYTy8/download?path=%2F&files=oscamaarch"
            else:

                if  cpuversion == "aarch64" :
                    logging.info("cpu ist eine aarch")
                    remote_urloscam = "https://magentacloud.de/s/dBmmC8JEjiyYTy8/download?path=%2F&files=oscamaarch"
                else:
                    logging.info("cpu fehler nicht gefunden")
                    sys.exit(1)

    if cpuversion != "none" :
        download_file(remote_urloscam, local_path)
        sys.exit(0)
    else:
        logging.info("cpu info nicht vorhanden kein download ")
        sys.exit(1)

def cpuneu():
    print("keine info in cpuversion")
    # Datei in /tmp kopieren
    OSCAM_INFO_FILE = "/tmp/.oscam/oscam.version"  # Beispielpfad
    TMP_FILE = "/tmp/oscam.version"
    try:
        shutil.copy2(OSCAM_INFO_FILE, TMP_FILE)
        logging.info("Datei kopiert: %s -> %s", OSCAM_INFO_FILE, TMP_FILE)
    except Exception as e:
        logging.error("Fehler beim Kopieren: %s", str(e))
        sys.exit(1)

    # Prüfen, ob Datei existiert
    if os.path.exists(TMP_FILE):
        cpuversion = ""
        with open(TMP_FILE, "r") as f:
            for zeile in f:
                if "Compiler" in zeile:
                    logging.info("CPU-Version gefunden")
                    cpuversion = zeile.split(":", 1)[1].strip()
                    cputyp = cpuversion.split("-")[0]
                    cpuversion = cputyp
                    print("cpuversion : %s" % cpuversion)
                    update_version(cpuversion)
    else:
        logging.info("CPU-Version nicht gefunden")
        sys.exit(1)

if __name__ == "__main__":
    valid_types = {"arm", "aarch", "mipsel", "aarch64"}
    if len(sys.argv) == 2:
        cpuversion = sys.argv[1].strip().lower()
        print("uebergabe %s " % cpuversion)
        if cpuversion.split("-")[0] in valid_types:
            logging.info("CPU-Version über Argument erhalten: %s", cpuversion)
            print("cpu info ok")
            update_version(cpuversion)
        else:
            logging.info("falsche uebergabe")
            print("falsch")
            cpuneu()
    else:
        logging.info("leer")
        print("leer")
        cpuneu()









