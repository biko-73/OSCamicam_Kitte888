#!/usr/bin/env python
# -*- coding: utf-8 -*-

import logging
import subprocess
import os
import sys
import shutil
# Übergebener Oscam-Name (aus Argument)
oscamname = "oscamicamall"

# Konfiguration
TMP_BINARY = "/tmp/oscamicamall.new"
BIN_DIR = "/etc/tuxbox/config/oscamicamall/binary"
BACKUP_SUFFIX = ".old"
LOGFILE = "/tmp/kitte888_oscam_binary.log"

# Logging einrichten
logging.basicConfig(filename=LOGFILE, level=logging.INFO, format='%(asctime)s - %(message)s')
logging.info("**************************** START *******************************")

def check_binary():
    # Prüfen, ob ein Oscam-Name übergeben wurde
    if not oscamname:
        logging.error("Fehler: Kein Oscam-Name angegeben.")
        sys.exit(1)

    # Sicherstellen, dass die neue Binary existiert
    if not os.path.isfile(TMP_BINARY):
        logging.error("Fehler: Neue Oscam-Binary ({}) existiert nicht.".format(TMP_BINARY))
        sys.exit(1)

    # Prüfen, ob die alte Binary existiert
    if not os.path.isfile(os.path.join(BIN_DIR, oscamname)):
        logging.error("Fehler: Alte Oscam-Binary ({}) existiert nicht.".format(os.path.join(BIN_DIR, oscamname)))
        sys.exit(1)

    stop_process(oscamname)

    # Backup der alten Binary erstellen
    logging.info("Erstelle Backup für {}...".format(oscamname))
    #os.rename(os.path.join(BIN_DIR, oscamname), os.path.join(BIN_DIR, oscamname + BACKUP_SUFFIX))

    source_path = "/etc/tuxbox/config/oscamicamall/binary/oscamicamall"
    destination_path = "/etc/tuxbox/config/oscamicamall/binary/oscamicamall.old"
    shutil.copy(source_path, destination_path)

    # Neue Binary kopieren und ausführbar machen
    logging.info("Kopiere neue Binary ({}) nach {}...".format(TMP_BINARY, os.path.join(BIN_DIR, oscamname)))
    #copy_process = subprocess.Popen(["cp", TMP_BINARY, os.path.join(BIN_DIR, oscamname)])
    #copy_process.communicate()  # Warten auf den Abschluss des Prozesses
    source_path = "/tmp/oscamicamall.new"
    destination_path = "/etc/tuxbox/config/oscamicamall/binary/oscamicamall"
    shutil.copy(source_path, destination_path)

    os.chmod(os.path.join(BIN_DIR, oscamname), 0o755)  # Setze die Berechtigung

    logging.info("Oscam-Binary erfolgreich aktualisiert.")

def stop_process(oscam_name):
    try:
        # Stoppe den Prozess mit killall
        logging.info("Beende Oscam-Prozess: {}".format(oscam_name))
        stop_process = subprocess.Popen(["killall", oscam_name])
        stop_process.communicate()  # Warten auf den Abschluss des Prozesses
        logging.info("Oscam {} wurde gestoppt.".format(oscam_name))
        print("Oscam {} wurde gestoppt.".format(oscam_name))
    except OSError as e:
        logging.error("Fehler beim Stoppen des Oscam-Prozesses: {}".format(e))

if __name__ == "__main__":
    check_binary()